package main.rice;

import main.rice.basegen.BaseSetGenerator;
import main.rice.concisegen.ConciseSetGenerator;
import main.rice.parse.ConfigFile;
import main.rice.parse.ConfigFileParser;
import main.rice.parse.InvalidConfigException;
import main.rice.test.TestCase;
import main.rice.test.TestResults;
import main.rice.test.Tester;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public class Main {

    /**
     * Calls generateTests to run the tests and the set cover algorithm.
     * then prints the results to console.
     *
     * @param args String arguments to be used for tests. Includes, in order,
     *             the String path to the JSON config file, the String path
     *             to the reference solution file, and the String path the
     *             directory with the buggy implementations.
     * @throws IOException if a file is not found at the defined path.
     * @throws InvalidConfigException if the config file is in an invalid format
     * to be parsed.
     * @throws InterruptedException if the testing process is interrupted.
     */
    public static void main(final String[] args)
            throws IOException, InvalidConfigException, InterruptedException {
        Set<TestCase> tests = generateTests(args);
        System.out.print(tests);
    }

    /**
     * Runs the tests and the set cover algorithm.
     *
     * @param args String arguments to be used for tests. Includes, in order,
     *             the String path to the JSON config file, the String path
     *             to the reference solution file, and the String path the
     *             directory with the buggy implementations.
     * @return the Set of TestCases cover created by
     * ConciseSetGenerator using the test results.
     * @throws IOException if a file is not found at the defined path.
     * @throws InvalidConfigException if the config file is in an invalid format
     * to be parsed.
     * @throws InterruptedException if the testing process is interrupted.
     */
    public static Set<TestCase> generateTests(final String[] args)
            throws IOException, InvalidConfigException, InterruptedException {
        //Reads and parses JSON config file
        String stringConfig = ConfigFileParser.readFile(args[0]);
        ConfigFile myConfig = ConfigFileParser.parse(stringConfig);

        //Gets the base test set
        BaseSetGenerator myBaseSetGen =
                new BaseSetGenerator(
                        myConfig.getNodes(), myConfig.getNumRand());
        List<TestCase> baseSet = myBaseSetGen.genBaseSet();

        //Runs tests
        Tester myTester =
                new Tester(myConfig.getFuncName(), args[1], args[2], baseSet);
        myTester.computeExpectedResults();
        TestResults myResults = myTester.runTests();

        //Creates and returns set of tests that "cover" bugs
        return ConciseSetGenerator.setCover(myResults);
    }
}
