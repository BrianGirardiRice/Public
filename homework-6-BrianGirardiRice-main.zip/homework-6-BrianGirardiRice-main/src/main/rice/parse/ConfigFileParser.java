package main.rice.parse;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import main.rice.node.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ConfigFileParser {

    /**
     * Reads the JSONConfig from filepath.
     *
     * @param filepath the path to the config file to be read.
     * @return the text of the JSON config file as a single String object.
     * @throws IOException if file cannot be found.
     */
    public static String readFile(final String filepath) throws IOException {
        return Files.readString(Paths.get(filepath));
    }

    /**
     * Takes the string contents of a JSON config file and converts it
     * to a Java ConfigFile object.
     *
     * @param contents a String representation of the text on a JSON config
     *                 file. Determined with readFile.
     * @return a ConfigFile object, which includes the function name,
     * a list of the APyNodes, and the random number used for generation.
     * @throws InvalidConfigException if the JSON config is invalid and cannot be
     * parsed, including a message of what was wrong.
     */
    public static ConfigFile parse(String contents)
            throws InvalidConfigException {
        //Attempts to convert JSON config to JSONObject
        contents = contents.strip();
        JSONObject myData;
        try {
            myData = new JSONObject(contents);
        } catch (Exception e) {
            throw new InvalidConfigException("Config is not in JSON format");
        }

        //Assigns variables for the keys in the JSONObject,
        //to be defined by accessed values
        String fName;
        List<String> types;
        List<String> exDomains;
        List<String> ranDomains;
        int numRand;
        try {
            fName = myData.getString("fname");

            types = getStringList(myData.getJSONArray("types"));

            Object numRandObj = myData.get("num random");
            if (!(numRandObj instanceof Integer)) {
                throw new InvalidConfigException("Value for numRand is"
                        + " not a valid integer.");
            }
            numRand = myData.getInt("num random");

            ranDomains = getStringList(myData.getJSONArray("random domain"));

            exDomains = getStringList(myData.getJSONArray("exhaustive domain"));
        } catch (JSONException j) {
            //When a trying to get the value at a key fails,
            //because the key's wrong/missing or the value at that key
            //is the wrong type.
            throw new InvalidConfigException("error in JSON key value pairs. "
                    + "either a key is invalid or missing, or the"
                    + " value is in an incorrect format for the given key");
        }

        List<APyNode<?>> nodes = buildPyNodes(types, exDomains, ranDomains);
        return new ConfigFile(fName, nodes, numRand);
    }

    /**
     * Given the types and domains, constructs APyNodes one by one.
     *
     * @param types a List of the types of java objects for nodes to be made,
     *              represented by a String.
     * @param exDomains A List of the exhaustive domains
     *                  associated with each of the types.
     * @param ranDomains A List of the random domains
     *      *                  associated with each of the types.
     * @return A list all the APYNodes for the config file (to be later
     * used in BaseSetGen).
     * @throws InvalidConfigException if the number of types and domains are
     * unequal, or if something goes wrong during individual node creation and
     * a thrown InvalidConfigException propagates up the stack.
     */
    private static List<APyNode<?>> buildPyNodes(
            final List<String> types, final List<String> exDomains, final List<String> ranDomains)
                throws InvalidConfigException {
        List<APyNode<?>> nodes = new LinkedList<>();

        //Makes sure the number of domains and types match, throw exception
        //if they don't.
        if (types.size() == exDomains.size() && types.size() == ranDomains.size()) {

            //Creates a single node from each index
            for (int i = 0; i < types.size(); i++) {
                nodes.add(assembleNode(
                        types.get(i), exDomains.get(i), ranDomains.get(i)));
            }

        } else {
            throw new InvalidConfigException("Number of domains and number"
                    + " of types are not equivalent.");
        }
        return nodes;
    }

    /**
     * Recursively assembles a single APyNode of an unknown subclass type.
     *
     * @param type the type of APyNode to be generated and its child nodes,
     *             represented by a single string.
     * @param exDomains the exhaustive domains for the generated APyNode and
     *                  its child nodes, represented by a single string.
     * @param ranDomains the random domains for the generated APyNode and
     *      *           its child nodes, represented by a single string.
     * @return A single APyNode (will be a subclass of APyNode),
     * created from the inputted information.
     * @throws InvalidConfigException if inputted Strings are not valid for
     * the creation of a node.
     */
    private static APyNode<?> assembleNode(
            final String type, final String exDomains, final String ranDomains)
            throws InvalidConfigException {
        //Base case, simple node type
        if (!type.contains("(")) {
            return assembleMundaneNode(type, exDomains, ranDomains);
        }
        //Recursive case, has a parenthesis
        APyNode<?> myNode;

        //Separates info for this specific node and for children.
        String[] splitType = type.split("[(]", 2);
        String[] splitExDom = exDomains.split("[(]", 2);
        String[] splitRanDom = ranDomains.split("[(]", 2);
        String myType = splitType[0].strip();
        APyNode<?> leftChild;
        if (myType.equals("dict")) {
            //Splits between key and value info in dictionary
            String[] keyValueTypes = splitType[1].split(":", 2);
            String[] keyValueExDom = splitExDom[1].split(":", 2);
            String[] keyValueRanDom = splitRanDom[1].split(":", 2);
            //Tries to assemble key and value child nodes. If something is wrong with dict,
            //these will throw exception in process.
            leftChild =
                    assembleNode(keyValueTypes[0].strip(),
                            keyValueExDom[0].strip(), keyValueRanDom[0].strip());
            APyNode<?> rightChild =
                    assembleNode(keyValueTypes[1].strip(),
                            keyValueExDom[1].strip(), keyValueRanDom[1].strip());
            myNode = new PyDictNode<>(leftChild, rightChild);
        } else if (myType.equals("str")) {
            //Separates off the domain, goes through each index,
            //and uses them all as charDomain fo PyStringNode.
            String domain = splitType[1].strip();
            Set<Character> charDomain = new HashSet<>();
            for (int i = 0; i < domain.length(); i++) {
                charDomain.add(domain.charAt(i));
            }
            myNode = new PyStringNode(charDomain);
        } else {
            //Assemble leftChild to be taken by constructors.
            try {
                leftChild =
                        assembleNode(splitType[1], splitExDom[1], splitRanDom[1]);
            } catch (IndexOutOfBoundsException i) {
                throw new InvalidConfigException("Number of layers of types and values do not match"
                        + " (often caused by extra or missing parenthesis)");
            }
            //Finds iterable type and returns AIterablePyNode of that
            //type with leftChild
            myNode = switch (myType) {
                case "list" -> new PyListNode<>(leftChild);
                case "tuple" -> new PyTupleNode<>(leftChild);
                case "set" -> new PySetNode<>(leftChild);
                default -> throw new InvalidConfigException("Type before parenthesis does not match valid "
                        + "iterable or dict type");
            };
        }
        //Using domainHelper, computes and sets domains for APyNode and returns.
        myNode.setExDomain(domainHelper(splitExDom[0].strip()));
        myNode.setRanDomain(domainHelper(splitRanDom[0].strip()));
        return myNode;
    }

    /**
     * Assembles a single APyNode of a "simple" subclass type;
     * that is, one based around a primitive Java type.
     *
     * @param type the type of simple APyNode represented by a string.
     * @param exDomain the exDomain of the APyNode to be generated,
     *                 represented by a string.
     * @param ranDomain the ranDomain of the APyNode to be generated,
     *      *                 represented by a string.
     * @return a single APyNode with no children.
     * @throws InvalidConfigException if inputted Strings are not valid for
     *      * the creation of a APyNode with no child nodes.
     */
    private static APyNode<?> assembleMundaneNode(
            final String type, final String exDomain, final String ranDomain)
                throws InvalidConfigException {
        APyNode<?> myNode;
        //Uses domainHelper to compute domains.
        List<Number> finalExDom = domainHelper(exDomain);
        List<Number> finalRanDom = domainHelper(ranDomain);

        //Gets the (domainless) APyNode. Also fixes the domain issues,
        //or throws an exception if impossible.
        myNode = fixMundaneType(type, finalExDom, finalRanDom);

        myNode.setExDomain(finalExDom);
        myNode.setRanDomain(finalRanDom);
        return myNode;
    }

    /**
     * Helper method for assembleMundaneNode. Improves abstraction.
     * Finds the type of APyNode from given String type, and finds/fixes
     * any issues of incorrect types in domains.
     *
     * @param type the type of simple APyNode represented by a string.
     * @param finalExDom the exDomain of the APyNode to be generated,
     *      *                 represented by a string.
     * @param finalRanDom the ranDomain of the APyNode to be generated,
     *      *                 represented by a string.
     * @return a blank APyNode, of the correct subclass type.
     * @throws InvalidConfigException If type is not a valid node type,
     * or if domain contains an invalid value for the inputted type.
     */
    private static APyNode<?> fixMundaneType(
            final String type, final List<Number> finalExDom, final List<Number> finalRanDom)
                throws InvalidConfigException {
        APyNode<?> myNode;

        //Keeps track of if domain can be used, to throw exception if not.
        boolean validDoms = true;

        switch (type) {
            case "int" -> {
                myNode = new PyIntNode();

                //Finds not ints in int domains.
                for (Number num : finalExDom) {
                    if (!(num instanceof Integer)) {
                        validDoms = false;
                        break;
                    }
                }
                for (Number num : finalRanDom) {
                    if (!(num instanceof Integer)) {
                        validDoms = false;
                        break;
                    }
                }

            }
            case "bool" -> {

                //Finds numbers that cannot represent bools in bool domain.
                for (Number num : finalExDom) {
                    if (!(num.equals(0) || num.equals(1))) {
                        validDoms = false;
                        break;
                    }
                }
                for (Number num : finalRanDom) {
                    if (!(num instanceof Integer)) {
                        validDoms = false;
                        break;
                    }
                }

                myNode = new PyBoolNode();
            }
            case "float" -> {
                //Replaces non-double numbers in domain
                //with appropriate double value.
                finalExDom.replaceAll(Number::doubleValue);
                finalRanDom.replaceAll(Number::doubleValue);
                myNode = new PyFloatNode();
            }
            default -> throw new InvalidConfigException("Invalid node type.");
        }
        if (!validDoms) {
            throw new InvalidConfigException("One or more values in domain"
                    + " cannot be used for given type");
        }
        return myNode;
    }

    /**
     * Finds a domain based on the String representation.
     *
     * @param domString A string representing a single range or iterable
     *                  domain.
     * @return a list of numbers to be the domain of the APyNode being created
     * @throws InvalidConfigException if the string representation of the domain
     * is invalid, or if the domain contains a "("
     * (Since this should only receive the domain for one node and
     *  not its children)
     */
    private static List<Number> domainHelper(final String domString)
            throws InvalidConfigException {
        List<Number> domain = new LinkedList<>();

        //This should be the domain of a single node,
        //not including its child.
        if (domString.contains("(")) {
            throw new InvalidConfigException("Unexpected parenthesis in domain"
                    + " (could also be caused by missing parenthesis in types");
        }

        //Runs on domains represented by an int range
        if (domString.contains("~")) {
            String[] splitDom = domString.split("~");
            int start;
            int end;
            try {

                //Adds each int from start to end.
                start = Integer.parseInt(splitDom[0].strip());
                end = Integer.parseInt(splitDom[1].strip());
                for (int i = start; i <= end; i++) {
                    domain.add(i);
                }

            } catch (Exception e) {
                throw new InvalidConfigException("Range of values for domain"
                        + " is invalid or contains a non-integer value.");
            }

        } else {
            //Removes outer brackets of iterable domain.
            String noBrackets = domString.substring(1, domString.length() - 1);
            String[] simpleArray = noBrackets.split(",");
            //Splits on comma and adds each element to domain.
            for (String s: simpleArray) {
                Number newNum;
                //Tries to parse as int, then tries double
                //if that fails.
                try {
                    newNum = Integer.parseInt(s.strip());
                } catch (Exception notInt) {
                    try {
                        newNum = Double.parseDouble(s.strip());
                    } catch (Exception notValid) {
                        throw new InvalidConfigException("Value in iterable"
                                + " domain is not a valid number.");
                    }
                }
                domain.add(newNum);
            }
        }
        return domain;
    }

    /**
     * Converts JSONArrays to Lists of Strings.
     *
     * @param value a valid JSONArray.
     * @return A List of Strings representing the values in the JSONArray.
     * @throws InvalidConfigException if a value in the JSONArray cannot
     * be cast to String.
     */
    private static List<String> getStringList(final JSONArray value)
            throws InvalidConfigException {
        List<String> chopped = new LinkedList<>();
        for (Object string: value) {
            //Converts each object in JSON array to String and adds to List
            try {
                chopped.add((String) string);
            } catch (ClassCastException c) {
                throw new InvalidConfigException("Types or domains are not properly seperated"
                        + "by commas");
            }
        }
        return chopped;
    }
}
