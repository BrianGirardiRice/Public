package main.rice.parse;

import main.rice.node.APyNode;

import java.util.List;

public class ConfigFile {

    /**
     * A string representing the name of the function the config
     * file is for.
     */
    private final String funcName;

    /**
     * A list of the APyNodes of the config file, to be used in
     * BaseSetGenerator.
     */
    private final List<APyNode<?>> nodes;

    /**
     * The integer number used for random generation.
     */
    private final int numRand;

    /**
     * Constructs a ConfigFile object by storing
     * inputted information to fields.
     *
     * @param funcName A string representing the name of the function.
     * @param nodes A List of the APyNodes of the config file.
     * @param numRand The integer number used for random generation.
     */
    public ConfigFile(
            final String funcName, final List<APyNode<?>> nodes, final int numRand) {
        this.funcName = funcName;
        this.nodes = nodes;
        this.numRand = numRand;
    }

    /**
     * Getter method. Gets the function Name.
     *
     * @return the value in the String funcName field.
     */
    public String getFuncName() {
        return this.funcName;
    }

    /**
     * Getter method. Gets the APyNodes.
     *
     * @return the value in the List<APyNode> nodes field.
     */
    public List<APyNode<?>> getNodes() {
        return this.nodes;
    }

    /**
     * Getter method. Gets the number used for random generation.
     *
     * @return the value in the int numRand field.
     */
    public int getNumRand() {
        return this.numRand;
    }
}
