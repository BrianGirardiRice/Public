def func0(intval):
    if intval in [1, 3]:
        return intval + 1
    return intval