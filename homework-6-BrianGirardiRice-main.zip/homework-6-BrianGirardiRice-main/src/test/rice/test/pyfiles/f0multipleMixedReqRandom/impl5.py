def func0(intval):
    if intval in [5, 6, 7, 8, 9]:
        return intval + 1
    return intval