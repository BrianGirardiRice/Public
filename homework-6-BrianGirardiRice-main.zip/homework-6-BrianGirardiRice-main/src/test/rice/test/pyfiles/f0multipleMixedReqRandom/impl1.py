def func0(intval):
    if intval in [1, 2]:
        return intval + 1
    return intval