def func0(intval):
    if intval in [0, 1]:
        return intval + 1
    return intval