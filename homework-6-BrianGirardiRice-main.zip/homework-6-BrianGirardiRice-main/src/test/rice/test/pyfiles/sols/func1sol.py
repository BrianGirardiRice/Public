def func1(bool_val, int_val, float_val):
    if bool_val:
        return int_val * float_val
    else:
        return int_val + float_val