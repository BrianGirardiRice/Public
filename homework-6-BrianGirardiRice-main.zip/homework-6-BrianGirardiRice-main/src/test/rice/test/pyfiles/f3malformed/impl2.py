def func3(set_val, list_val, tup_val):
    raise Exception
