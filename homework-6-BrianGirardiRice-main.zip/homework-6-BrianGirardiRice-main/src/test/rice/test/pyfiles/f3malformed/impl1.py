def f3(set_val, list_val):
    if (set_val):
        return tuple([str(min(set_val) - 1)])
    elif (len(list_val) > 5):
        return tuple([str(list_val[0] - 2)])
    elif (tup_val):
        return tuple([str(-3)])
    return ('0',)
