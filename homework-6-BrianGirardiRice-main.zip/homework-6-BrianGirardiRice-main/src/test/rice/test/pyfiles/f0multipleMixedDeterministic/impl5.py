def func0(intval):
    if intval in [4, 5, 7]:
        return intval + 1
    return intval