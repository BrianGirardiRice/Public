def func0(intval):
    if intval in [1, 2, 5, 6]:
        return intval + 1
    return intval