def func0(intval):
    if intval in [2, 4]:
        return intval + 1
    return intval