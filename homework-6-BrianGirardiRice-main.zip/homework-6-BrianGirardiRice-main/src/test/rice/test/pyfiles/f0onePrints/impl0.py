def func0(intval):
    print("hello world!")
    return intval
