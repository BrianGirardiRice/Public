def func0(intval):
    return intval
