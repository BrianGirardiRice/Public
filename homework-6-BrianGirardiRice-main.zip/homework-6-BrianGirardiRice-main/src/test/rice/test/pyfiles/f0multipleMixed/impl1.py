def func0(intval):
    if (intval % 2 == 0):
        return intval
    return intval + 1
